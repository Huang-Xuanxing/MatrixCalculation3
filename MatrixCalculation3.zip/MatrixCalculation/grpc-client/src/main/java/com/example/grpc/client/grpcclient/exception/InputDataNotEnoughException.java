package com.example.grpc.client.grpcclient.exception;

public class InputDataNotEnoughException extends Exception{
}
