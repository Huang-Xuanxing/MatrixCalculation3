package com.example.grpc.client.grpcclient.exception;

public class InputFormatNotFitException extends Exception{
}
